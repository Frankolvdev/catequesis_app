# MegaZIP 128 — Facebook y continuidad de paridad legacy

## Cambios aplicados
- Facebook App ID nuevo configurado por defecto: `1463167569060482`.
- Se añadió `fb_login_protocol_scheme` (`fb1463167569060482`) para compatibilidad con el flujo Android de Meta.
- Se añadió `FACEBOOK_CLIENT_TOKEN` a BuildConfig y una validación explícita antes de iniciar Facebook Login. No se inventa el token: falta copiar el Client Token real desde Meta.
- Se conserva Facebook SDK moderno `facebook-login:18.3.0`; no se añadió el SDK 4.x obsoleto sugerido por el Quickstart.
- Se activó `android:enableOnBackInvokedCallback="true"` para eliminar la advertencia de Android moderno y usar el back callback actual.

## Hashes de Meta ya obtenidos
- Debug: `JuIZeVztkj6crBPVQ/4+E3BS81A=`
- Producción / Google Play: `ZrGs4SoqFfa/Q53U/6VzosCjALM=`

## Auditoría app vieja ↔ app nueva
La base actual ya contiene equivalentes modernos para pantallas que informes anteriores marcaban como pendientes: perfil/datos, cursos aprobados, certificados, ayuda/información, ajustes, noticias, oración, contacto, chat invitado/autenticado, juegos (quiz, verdadero/falso, match, ahorcado, enigma, crucigrama), pizarra, actividades con imagen y lectura. No se reintrodujeron Activities legacy duplicadas.

## Pendientes externos (no solucionables inventando credenciales)
1. `FACEBOOK_CLIENT_TOKEN`: obtener de Meta y colocarlo en `gradle.properties` como `FACEBOOK_CLIENT_TOKEN=...`.
2. Firebase Realtime Database: el servidor está rechazando la URL configurada; confirmar la URL real en Firebase Console.
3. Google Sign-In: falta confirmar/renovar el Web Client ID de producción.

## Nota
Los avisos ZTE (`unipnp`, `IntelliText`, `SuperKiller`, `smartslide`) pertenecen al firmware del dispositivo y no son fallos de la app.
